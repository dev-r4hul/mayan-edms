default_app_config = 'mayan.apps.converter.apps.ConverterApp'
