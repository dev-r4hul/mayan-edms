default_app_config = 'mayan.apps.appearance.apps.AppearanceApp'
