TEST_CHECKOUT_INDEX_NODE_TEMPLATE = '{{ document.get_check_out_info }}'
