default_app_config = 'mayan.apps.autoadmin.apps.AutoAdminAppConfig'
