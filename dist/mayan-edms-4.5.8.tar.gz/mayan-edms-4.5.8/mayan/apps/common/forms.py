from mayan.apps.views.forms import FileDisplayForm


class LicenseForm(FileDisplayForm):
    DIRECTORY = ()
    FILENAME = 'LICENSE'
