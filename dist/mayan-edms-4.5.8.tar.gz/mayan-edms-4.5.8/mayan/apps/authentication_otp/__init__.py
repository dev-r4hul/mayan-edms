default_app_config = 'mayan.apps.authentication_otp.apps.AuthenticationOTPApp'
