default_app_config = 'mayan.apps.backends.apps.BackendsApp'
