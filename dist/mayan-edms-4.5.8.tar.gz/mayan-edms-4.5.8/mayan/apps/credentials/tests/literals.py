TEST_STORED_CREDENTIAL_BACKEND_PATH = 'mayan.apps.credentials.tests.credential_backends.TestCredentialBackend'
TEST_STORED_CREDENTIAL_BACKEND_DATA_FIELDS = {
    'test_field': 'test_value'
}
TEST_STORED_CREDENTIAL_BACKEND_DATA_PASSWORD = 'test_credential_password'
TEST_STORED_CREDENTIAL_BACKEND_DATA_USERNAME = 'test_credential_username'
TEST_STORED_CREDENTIAL_INTERNAL_NAME = 'test_credential'
TEST_STORED_CREDENTIAL_LABEL = 'test credential'
TEST_STORED_CREDENTIAL_LABEL_EDITED = 'test credential edited'
