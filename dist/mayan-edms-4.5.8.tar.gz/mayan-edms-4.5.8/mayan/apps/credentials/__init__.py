default_app_config = 'mayan.apps.credentials.apps.CredentialsApp'
